
package PuntoVenta2;

import javax.swing.JOptionPane;

public class ColaDeterminada {
int [] cola;
       
       int frente,atras;
       
       public ColaDeterminada(int n){
           cola = new int[n];
           
           atras = 0;
           frente = 0;
       }
    
       public boolean esVacia(){
           return atras == 0;
       }
       public boolean esLlena(){
           return atras == cola.length;
       }
       public void insertar(int a){
           cola[atras] = a;
           atras++;
       }
       
       public void quitar(){
           atras--;
           int a = cola[0];
           for (int i = 0; i < atras; i++) {
               cola[i] = cola[i + 1];
           }
       
           
       }
    public int[] turnos(){
        return cola;
    }
        
    }



 


