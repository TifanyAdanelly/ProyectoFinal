
package PuntoVenta2;

public class nodoA {
    
    Ropa dato;
    nodoA izq;
    nodoA der;
    
    public nodoA(Ropa d){
    this.dato = d;
    izq=der=null;
    
    }

    
}
