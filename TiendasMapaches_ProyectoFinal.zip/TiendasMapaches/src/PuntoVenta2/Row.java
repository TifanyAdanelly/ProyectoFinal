

package PuntoVenta2;

public class Row {
    private static int row;
    public static int getRow(){
        return row;
    }
    public static void setRow(){
        row++;
    }
    public static void setRow( int temp){
        row= temp;
    }


}
