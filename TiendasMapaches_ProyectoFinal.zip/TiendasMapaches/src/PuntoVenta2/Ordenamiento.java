
package PuntoVenta2;

public class Ordenamiento {
    Ropa [] ropita;
    public void quick(Ropa []arreglo, int primero,int ultimo){
        int i,j,pivote;
        Ropa auxiliar;
        i=primero;
        j=ultimo;
        pivote=arreglo[(primero+ultimo)/2].getCantidad();
        do{
            while(arreglo[i].getCantidad()<pivote){
                i++;
            }
            while(arreglo[j].getCantidad()>pivote){
                j--;
            }
            if(i<=j){
                auxiliar=arreglo[i];
                arreglo[i]=arreglo[j];
                arreglo[j]=auxiliar;
                i++;
                j--;
            }
        }while(i<=j);
        if(primero<j){
            quick(arreglo, primero, j);
        }
        if(i<ultimo){
            quick(arreglo, i, ultimo);
        }
        Arreglo(arreglo);
}
    public void Arreglo(Ropa[]arreglo){
        int k;
        ropita=new Ropa[arreglo.length];
        
        for(k=0;k<arreglo.length;k++){
            
            ropita[k]=arreglo[k];
            System.out.println("["+arreglo[k].getNombrePro()+"]"+"["+arreglo[k].getCantidad()+"]");
            
        }
        System.out.println("Fin----------------");
    }
    public Ropa[] ropita(){
        return ropita;
    }
}
