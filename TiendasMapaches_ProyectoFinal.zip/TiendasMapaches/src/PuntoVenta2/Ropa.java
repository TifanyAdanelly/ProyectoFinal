
package PuntoVenta2;


public class Ropa {
private String nombrePro;
    private int cantidad;
    private float precio;

    public Ropa(String nombrePro, int cantidad, float precio) {
        setNombrePro(nombrePro);
        setCantidad(cantidad);
        setPrecio(precio);
    }
    
    public String getNombrePro() {
        return nombrePro;
    }
    public void setNombrePro(String nombrePro) {
        this.nombrePro = nombrePro;
    }
    public int getCantidad() {
        return cantidad;
    }
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    public float getPrecio() {
        return precio;
    }
    public void setPrecio(float precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return nombrePro+","+cantidad+","+precio;
    }
    
}
