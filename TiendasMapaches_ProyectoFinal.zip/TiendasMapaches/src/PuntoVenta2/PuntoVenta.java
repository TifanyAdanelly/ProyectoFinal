
package PuntoVenta2;

import java.io.*;
import java.util.ArrayList;
import javax.swing.*;

public class PuntoVenta extends javax.swing.JFrame {
//Declaarar Cola

    ColaDeterminada cola;
//Declarar Arbol
    ArbolS arbol = new ArbolS();
//Declarar el ordenamiento
    Ordenamiento orden;
//Inicializar la condición de ordenar
    int condicion;
//Declarar modelo de la lista para la cola
    DefaultListModel historial1;

    public PuntoVenta() {
        initComponents();
        //Bloquear boton pagar al iniciar el programa
        bPagar.setEnabled(false);
        //bloquear boton maximizar
        this.setResizable(false);
        //poner pantalla centro
        this.setLocationRelativeTo(null);
        //Titulo
        this.setTitle("Tiendas Mapaches");
        //Inicializar Cola
        cola = new ColaDeterminada(10);
        //Inicializar Arbol
        arbol = new ArbolS();
        //Inicializar Ordenamiento
        orden = new Ordenamiento();
        //Inicializar el modelo de la lista para la cola
        historial1 = new DefaultListModel();
        //Ingresar el modelo a la lista
        this.lista1.setModel(historial1);
        //Metodo para leer el archivo para la cola al iniciar el proyecto
        leerArchivos();
    }
    //Leer archivo Turno (para la cola)

    public void leerArchivos() {

        try {
            //Busca la ruta del archivo y la guarda en la variable "fr"
            FileReader fr = new FileReader("datos/turno.txt");
            BufferedReader br = new BufferedReader(fr);
            String aux = "";
            String linea = "";
            while ((linea = br.readLine()) != null) {
                int i = 0;
                aux = linea;
                //Guarda la información en un arreglo y les aplica un \n
                String[] a = aux.split("\n");
                int numero = Integer.parseInt(a[i]);
                //Se le inserta a la cola
                cola.insertar(numero);
                i++;

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }

        for (int i = 0; i < cola.turnos().length; i++) {
            //Llenado de la lista con los elementos encontrados de la cola
            this.historial1.addElement(cola.cola[i]);
        }
    }

//public int productos(int inicio,int fin,int[]array){
//    if(inicio==fin){
//        return array[inicio];
//    }
//    else{
//        int mitad=(inicio+fin)/2;
//        int x = productos(inicio, mitad, array);
//        int y=productos(mitad+1, fin, array);
//        return x+y;
//    }
//}
//public float inversion(int inicio,int fin,float[]arreglo){
//    if(inicio==fin){
//        return arreglo[inicio];
//    }
//    else{
//        int mitad=(inicio+fin)/2;
//        float x = inversion(inicio, mitad, arreglo);
//        float y = inversion(mitad+1, fin, arreglo);
//        return x+y;
//    }
//}
//Guardar los datos de cola cuando finaliza el programa
    public void wardar() {
        try {
            //Busca el archivo
            FileWriter fw = new FileWriter("datos/turno.txt");
            PrintWriter pw = new PrintWriter(fw);
            //Inserta los valores al archivo
            for (int i = 0; i < cola.turnos().length; i++) {
                pw.println(cola.cola[i]);
            }
            //Finaliza
            pw.close();
            fw.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    public void borrar2() {
        //Manda a traer al metodo quitar de la clase ColaDeterminada
        cola.quitar();
        //Inserta un nuevo dato
        cola.insertar(cola.cola[9] + 1);
        //Remueve el dato eliminado
        historial1.removeAllElements();
        //Recorre la lista y le agrega elementos de la cola actualizada
        for (int i = 0; i < cola.turnos().length; i++) {
            this.historial1.addElement(cola.cola[i]);
            wardar();

        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jToggleButton1 = new javax.swing.JToggleButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jTextField14 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jTextField10 = new javax.swing.JTextField();
        jTextField11 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        jTextField13 = new javax.swing.JTextField();
        bPagar = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        txtIndice = new javax.swing.JTextField();
        txtCantidad = new javax.swing.JTextField();
        jButton18 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        lista1 = new javax.swing.JList<>();
        bDeAaZ = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel24 = new javax.swing.JLabel();

        jButton1.setText("jButton1");

        jLabel4.setText("jLabel4");

        jToggleButton1.setText("jToggleButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Punto de Venta");

        jPanel1.setBackground(new java.awt.Color(255, 204, 204));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(255, 51, 255)));

        jTable1.setBackground(new java.awt.Color(204, 204, 255));
        jTable1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(255, 51, 204)));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Índice No.", "Nombre del Producto", "Cantidad", "Precio unitario"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setPreferredWidth(10);
            jTable1.getColumnModel().getColumn(1).setPreferredWidth(150);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setPreferredWidth(10);
            jTable1.getColumnModel().getColumn(3).setPreferredWidth(10);
        }

        jButton2.setBackground(new java.awt.Color(204, 255, 204));
        jButton2.setFont(new java.awt.Font("Vani", 1, 24)); // NOI18N
        jButton2.setForeground(new java.awt.Color(102, 0, 0));
        jButton2.setText("Actualizar");
        jButton2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, new java.awt.Color(0, 0, 0), new java.awt.Color(51, 153, 255), null));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jTabbedPane1.setBackground(new java.awt.Color(51, 153, 255));
        jTabbedPane1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(255, 51, 153)));
        jTabbedPane1.setForeground(new java.awt.Color(255, 51, 102));
        jTabbedPane1.setTabPlacement(javax.swing.JTabbedPane.LEFT);

        jPanel2.setBackground(new java.awt.Color(255, 255, 204));

        jLabel1.setBackground(new java.awt.Color(51, 153, 255));
        jLabel1.setFont(new java.awt.Font("Vani", 1, 18)); // NOI18N
        jLabel1.setText("Nombre del producto:");

        jLabel2.setBackground(new java.awt.Color(51, 153, 255));
        jLabel2.setFont(new java.awt.Font("Vani", 1, 18)); // NOI18N
        jLabel2.setText("Cantidad:");

        jLabel3.setBackground(new java.awt.Color(51, 153, 255));
        jLabel3.setFont(new java.awt.Font("Vani", 1, 18)); // NOI18N
        jLabel3.setText("Precio:   $");

        jTextField3.setBackground(new java.awt.Color(255, 204, 255));
        jTextField3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(255, 51, 153)));
        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });

        jTextField4.setBackground(new java.awt.Color(255, 204, 255));
        jTextField4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(255, 51, 153)));
        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });

        jTextField5.setBackground(new java.awt.Color(255, 204, 255));
        jTextField5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(255, 51, 153)));
        jTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(204, 255, 255));
        jButton5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 51, 153));
        jButton5.setText("Agregar");
        jButton5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(51, 153, 255)));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton6.setText("Borrar");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setBackground(new java.awt.Color(204, 255, 255));
        jButton7.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 51, 153));
        jButton7.setText("Limpiar");
        jButton7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(51, 153, 255)));
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jTextField14.setBackground(new java.awt.Color(255, 204, 255));
        jTextField14.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(255, 51, 153)));
        jTextField14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField14ActionPerformed(evt);
            }
        });

        jLabel7.setBackground(new java.awt.Color(51, 153, 255));
        jLabel7.setFont(new java.awt.Font("Vani", 1, 18)); // NOI18N
        jLabel7.setText("Nombre del Producto");

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel17.setText("Agregar Producto----------------------------------------------------------");

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel18.setText("Borrar Producto------------------------------------------------------------");

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/Logo-Peque.png"))); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel17)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(549, 549, 549))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel19)))
                .addGap(314, 314, 314))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel18)
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(330, 330, 330)
                        .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(211, 211, 211)
                        .addComponent(jButton6))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 299, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(154, 154, 154)
                        .addComponent(jLabel7))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, 404, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel17)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(48, 48, 48)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton7)
                    .addComponent(jButton5))
                .addGap(18, 18, 18)
                .addComponent(jLabel18)
                .addGap(18, 18, 18)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(jButton6)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Agregar/Borrar", jPanel2);

        jPanel5.setBackground(new java.awt.Color(255, 255, 204));
        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(255, 51, 153)));

        jTextField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField6ActionPerformed(evt);
            }
        });

        jTextField7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField7ActionPerformed(evt);
            }
        });

        jTextField8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField8ActionPerformed(evt);
            }
        });

        jTextField9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField9ActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setText("Nombre del actual producto:");

        jButton8.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton8.setText("Guardar cambios");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel14.setText("Cambiar nombre del producto:");

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel15.setText("Cantidad");

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel16.setText("Precio");

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/Logo-Peque.png"))); // NOI18N

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel21.setText("$");

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel22.setText("Actualizar Producto----------------------------");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(160, 160, 160)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel20))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel22)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jTextField7, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jTextField6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 461, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel5)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(55, 55, 55)
                                .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(83, 83, 83)
                                .addComponent(jLabel15)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addComponent(jLabel21)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(80, 80, 80))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel16)
                                .addGap(114, 114, 114)))))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel22)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel21)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );

        jTabbedPane1.addTab("Actualizar", jPanel5);

        jPanel4.setBackground(new java.awt.Color(255, 255, 204));
        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(255, 51, 102)));
        jPanel4.setForeground(new java.awt.Color(255, 51, 153));

        jTable2.setBackground(new java.awt.Color(255, 204, 255));
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Cantidad", "Nombre del Producto", "Precio Unitario", "Precio Total"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Double.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable2.getTableHeader().setReorderingAllowed(false);
        jScrollPane2.setViewportView(jTable2);
        if (jTable2.getColumnModel().getColumnCount() > 0) {
            jTable2.getColumnModel().getColumn(0).setPreferredWidth(10);
            jTable2.getColumnModel().getColumn(1).setPreferredWidth(150);
            jTable2.getColumnModel().getColumn(2).setPreferredWidth(10);
            jTable2.getColumnModel().getColumn(3).setPreferredWidth(10);
        }

        jTextField10.setEditable(false);
        jTextField10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField10ActionPerformed(evt);
            }
        });

        jTextField11.setEditable(false);

        jTextField12.setEditable(false);
        jTextField12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField12ActionPerformed(evt);
            }
        });

        jTextField13.setEditable(false);

        bPagar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        bPagar.setText("Pagar");
        bPagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPagarActionPerformed(evt);
            }
        });

        jButton17.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton17.setText("Limpiar");
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });

        txtIndice.setBackground(new java.awt.Color(255, 255, 204));
        txtIndice.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(255, 51, 153)));
        txtIndice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIndiceActionPerformed(evt);
            }
        });

        txtCantidad.setBackground(new java.awt.Color(255, 255, 204));
        txtCantidad.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(255, 51, 153)));
        txtCantidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCantidadActionPerformed(evt);
            }
        });

        jButton18.setBackground(new java.awt.Color(204, 255, 255));
        jButton18.setFont(new java.awt.Font("Vani", 1, 18)); // NOI18N
        jButton18.setForeground(new java.awt.Color(51, 51, 51));
        jButton18.setText("Compra");
        jButton18.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(51, 153, 255)));
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Vani", 1, 24)); // NOI18N
        jLabel6.setText("----------------Productos comprados----------------");

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel8.setText("Unidades");

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel9.setText("Pago");

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel10.setText("Precio total");

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel11.setText("Cambio");

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel12.setText("Índice No.");

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel13.setText("Cantidad");

        jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/Logo-Peque.png"))); // NOI18N

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(jLabel9)
                        .addGap(28, 28, 28))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jScrollPane2)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(bPagar)
                        .addGap(65, 65, 65)
                        .addComponent(jButton17)
                        .addGap(131, 131, 131))
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 518, Short.MAX_VALUE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtIndice))
                            .addComponent(jButton18, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel23)
                        .addGap(23, 23, 23))))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtIndice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(txtCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton18, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel10))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bPagar)
                    .addComponent(jButton17))
                .addGap(27, 27, 27))
        );

        jTabbedPane1.addTab("Compra", jPanel4);

        jScrollPane3.setViewportView(lista1);

        bDeAaZ.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        bDeAaZ.setText("Ordenar Unidades");
        bDeAaZ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bDeAaZActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton3.setText("Regresar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel24.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel24.setText("TURNO");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 99, Short.MAX_VALUE)
                        .addComponent(bDeAaZ)
                        .addGap(56, 56, 56))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 483, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 635, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton3))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))))
                .addGap(15, 15, 15))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 485, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 389, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(32, 32, 32)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bDeAaZ)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jLabel24)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton3)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // Boton Actualizar

        try {
            //Inicializando fila
            for (int r = 0; r < 100; r++) {
                //Inicializando columna
                for (int c = 0; c < 4; c++) {
                    //Agregar valores
                    jTable1.setValueAt(null, r, c);
                }
            }
            //leer archivo
            BufferedReader rdfile = new BufferedReader(new FileReader("datos/items.txt"));
            //Inicializar Arreglo de String
            String[] item = new String[100];
            //Inicialiazar Arreglo temporal
            String[] temp;

            int x = 0;  //Leer archivo
            while ((item[x] = rdfile.readLine()) != null) {
                //Separa la información con un "Tabulador"
                temp = item[x].split("\t");
                //Establece los Id en la tabla
                jTable1.setValueAt((1000 + x + 1), x, 0);
                for (int j = 1; j < 4; j++) {
                    //Agrega los valores que se guardaron en el arreglo temporal a la tabla
                    jTable1.setValueAt(temp[j - 1], x, j);
                }

                x++;
            }
            //finaliza la lectura
            rdfile.close();

        } catch (IOException e) {
        }

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
        //Boton Compra
        //Si la condición = 0
        if (condicion == 0) {
            try { //Lectura del archivo
                BufferedReader rdfile = new BufferedReader(new FileReader("datos/items.txt"));
                //Inicializar Arreglo para guardar las lineas obtenidas
                String[] itemline = new String[100];
                //Inicialización de variables
                String str;
                double price, total;
                int qty = 0, qty_prv = 0, qty_new = 0;
                boolean found = false, edited = false;
                //Se añade la informacion introducida en el txtIndice
                int idx = (Integer.parseInt(txtIndice.getText())) - 1001;
                // Lee una línea de texto hasta que encuentra un carácter de salto de línea
                for (int x = 0; (str = rdfile.readLine()) != null; x++) {
                    itemline[x] = str;
                }
                //Finaliza la lectura
                rdfile.close();

                int r = Row.getRow();
                for (int i = 0; itemline[i] != null; i++) {
                    //si el indice digitado en txtIndice es igual a i
                    if (idx == i) {
                        //"Encontrado" = True
                        found = true;
                        //Se añade la linea al arreglo temporal separados por el "Tabulador"
                        String[] temp = itemline[i].split("\t");
                        //Se añade la cantidad a comprar
                        qty = Integer.parseInt(txtCantidad.getText());
                        //Se establece la cantidad en existencia encontrada en la lectura
                        qty_prv = Integer.parseInt(temp[1]);
                        //Si la cantidad digitada es mayor a la existente y es diferente a 0
                        if ((qty > qty_prv) && (qty_prv != 0)) {
                            JOptionPane.showMessageDialog(null, "¡Insuficiencia de inventario!", "¡ERROR!", JOptionPane.WARNING_MESSAGE);
                        }
                        //Si la cantidad en existencia es = a 0
                        if (qty_prv == 0) {
                            JOptionPane.showMessageDialog(null, "¡Por el momento el producto no se encuentra en existencia!", "¡ERROR!", JOptionPane.WARNING_MESSAGE);
                        }//Si la cantidad  digitada es menor a la que se encuentra en existencia y es diferente de 0
                        if ((qty <= qty_prv) && (qty_prv != 0)) {
                            //se resta de la cantidad existente y se guarda en una nueva variable
                            qty_new = qty_prv - qty;
                            //se agrega el nuevo dato a la linea del Arreglo
                            itemline[i] = temp[0] + "\t" + qty_new + "\t" + temp[2];
                            //Se ingresan los datos a la tabla de venta
                            jTable2.setValueAt(qty, r, 0);
                            jTable2.setValueAt(temp[0], r, 1);
                            jTable2.setValueAt(Double.parseDouble(temp[2]), r, 2);
                            //Se obtiene el precio de la linea en temporal
                            price = Double.parseDouble(temp[2]);
                            //Se multiplica el precio * la cantidad comprada 
                            total = qty * price;
                            //Se agrega a la tabla
                            jTable2.setValueAt(total, r, 3);
                            //Se brinca a la siguiente fila para siguientes compras 
                            r++;
                            //La variable editado se establece como True
                            edited = true;
                        }
                    }

                }
                //Si "Encontrado" es Falso entonces
                if (!found) {
                    JOptionPane.showMessageDialog(null, txtIndice.getText() + ": Producto no válido", "¡ERROR!", JOptionPane.ERROR_MESSAGE);
                }
                //Si la tabla fue editada entonces
                if (edited) {
                    //Escribir los nuevos datos en el archivo
                    PrintWriter wrfile = new PrintWriter(new FileWriter("datos/items.txt"));
                    for (int i = 0; itemline[i] != null; i++) {
                        wrfile.println(itemline[i]);
                    }
                    //El boton Pagar se 
                    bPagar.setEnabled(true);
                    wrfile.close();
                    Row.setRow();
                }
                //Las cajas de texto se vuelven a inicializar
                txtIndice.setText("");
                txtCantidad.setText("");

            } catch (IOException e) {
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Algun dato ingresado es inválido!", "¡ERROR!", JOptionPane.ERROR_MESSAGE);
            }
        } else {//Si condicion es ! a 0
            try { //Se realiza el proceso anterior pero con los archivos previamente ordenados y ahora 
                //guardados en un archivo distinto
                BufferedReader rdfile = new BufferedReader(new FileReader("datos/nuevo.txt"));
                String[] itemline = new String[100];
                String str;
                double price, total;
                int qty = 0, qty_prv = 0, qty_new = 0;
                boolean found = false, edited = false;
                int idx = (Integer.parseInt(txtIndice.getText())) - 1001;

                for (int x = 0; (str = rdfile.readLine()) != null; x++) {
                    itemline[x] = str;
                }
                rdfile.close();

                int r = Row.getRow();
                for (int i = 0; itemline[i] != null; i++) {
                    if (idx == i) {
                        found = true;
                        String[] temp = itemline[i].split("\t");
                        qty = Integer.parseInt(txtCantidad.getText());
                        qty_prv = Integer.parseInt(temp[1]);
                        if ((qty > qty_prv) && (qty_prv != 0)) {
                            JOptionPane.showMessageDialog(null, "¡Insuficiencia de inventario!", "¡ERROR!", JOptionPane.WARNING_MESSAGE);
                        }
                        if (qty_prv == 0) {
                            JOptionPane.showMessageDialog(null, "¡Por el momento el producto no se encuentra en existencia!", "¡ERROR!", JOptionPane.WARNING_MESSAGE);
                        }
                        if ((qty <= qty_prv) && (qty_prv != 0)) {
                            qty_new = qty_prv - qty;
                            itemline[i] = temp[0] + "\t" + qty_new + "\t" + temp[2];
                            jTable2.setValueAt(qty, r, 0);
                            jTable2.setValueAt(temp[0], r, 1);
                            jTable2.setValueAt(Double.parseDouble(temp[2]), r, 2);
                            price = Double.parseDouble(temp[2]);
                            total = qty * price;
                            jTable2.setValueAt(total, r, 3);
                            r++;
                            edited = true;
                        }
                    }

                }

                if (!found) {
                    JOptionPane.showMessageDialog(null, txtIndice.getText() + ": Producto no válido", "!ERROR!", JOptionPane.ERROR_MESSAGE);
                }//En este caso se modificara la venta en el txt original
                if (edited) {
                    PrintWriter wrfile = new PrintWriter(new FileWriter("datos/items.txt"));
                    for (int i = 0; itemline[i] != null; i++) {
                        wrfile.println(itemline[i]);
                    }
                    bPagar.setEnabled(true);
                    wrfile.close();
                    Row.setRow();
                }

                txtIndice.setText("");
                txtCantidad.setText("");

            } catch (IOException e) {
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Algun dato ingresado es inválido!", "¡ERROR!", JOptionPane.ERROR_MESSAGE);

            }
        }

    }//GEN-LAST:event_jButton18ActionPerformed

    private void txtCantidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCantidadActionPerformed
        jButton18ActionPerformed(evt);
    }//GEN-LAST:event_txtCantidadActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
        //Limpiar Compra
        for (int r = 0; r < 100; r++) //Inicializar Fila
        {
            for (int c = 0; c < 4; c++) //Inicializar Columna
            {
                jTable2.setValueAt(null, r, c);
            }
        }
        //Vaciar cajas de textos, columnas y desactivar boton pagar
        bPagar.setEnabled(false);
        jTextField10.setText("");
        jTextField11.setText("");
        jTextField12.setText("");
        jTextField13.setText("");
        Row.setRow(0);
        jButton18.setEnabled(true);
    }//GEN-LAST:event_jButton17ActionPerformed

    private void bPagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPagarActionPerformed
        //Borrar el turno 
        borrar2();
        try {//Inicializar variables
            int itms = 0, tmp;
            //Recorrer tabla
            for (int r = 0; jTable2.getValueAt(r, 0) != null; r++) {
                //Recorrer columnas
                tmp = Integer.parseInt("" + jTable2.getValueAt(r, 0));
                itms += tmp;
            }//Enviar informacion a "Producto:"
            jTextField10.setText("" + itms);
            //Inicializar variable para el total
            double total = 0, tmp2;
            //Sumatoria
            for (int r = 0; jTable2.getValueAt(r, 3) != null; r++) {
                tmp2 = Double.parseDouble("" + jTable2.getValueAt(r, 3));
                total += tmp2;
            }//Enviar total a jtxtField12
            jTextField12.setText("" + total);

            double cash, change;
            //Cobrar
            do {
                cash = Double.parseDouble(JOptionPane.showInputDialog("Pago en efectivo:"));
                //Si el dinero en efectivo es menor al que se debe pagar

                if (cash < total) {
                    JOptionPane.showMessageDialog(null, "¡Dinero insuficiente!", null, JOptionPane.WARNING_MESSAGE);
                }

            } while (cash < total);
            jTextField11.setText("" + cash);
            jTextField13.setText("" + (cash - total));
            jButton18.setEnabled(false);
//Ingresar otro tipo de dato
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "¡Ingreso inválido!", "", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_bPagarActionPerformed

    private void jTextField12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField12ActionPerformed

    }//GEN-LAST:event_jTextField12ActionPerformed

    private void jTextField10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField10ActionPerformed

    }//GEN-LAST:event_jTextField10ActionPerformed

    private void jTextField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField6ActionPerformed

    }//GEN-LAST:event_jTextField6ActionPerformed

    private void jTextField7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField7ActionPerformed
        jButton8ActionPerformed(evt);
    }//GEN-LAST:event_jTextField7ActionPerformed

    private void jTextField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField8ActionPerformed
        jButton8ActionPerformed(evt);
    }//GEN-LAST:event_jTextField8ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // Guardar Cambios (Actualizar)

        try {
            //Si la caja de texto esta vacia 
            if (jTextField6.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Ingrese producto", "¡ERROR!", JOptionPane.ERROR_MESSAGE);
            } else {
                //Lectura de archivo
                BufferedReader rdfile = new BufferedReader(new FileReader("datos/items.txt"));
                //Inicializar variables
                String[] itemline = new String[100];
                String temp[];
                String search = "", prod = "", Qty = "", Price = "";
                search = jTextField6.getText();
                int qty = 0, x = 0;
                double price = 0.0;
                boolean found = false;
                //Recibir datos de la caja de texto
                prod = jTextField7.getText();
                Qty = jTextField8.getText();
                Price = jTextField9.getText();
                //Si ninguna caja esta vacia entonces comienza a guardar en una variable temporal
                if ((!(prod.equals(""))) || (!(Qty.equals(""))) || (!(Price.equals("")))) {
                    while ((itemline[x] = rdfile.readLine()) != null) {
                        temp = itemline[x].split("\t");
                        //Verificar si el producto ya se encuentra registrado para su modificación
                        if (search.equals(temp[0])) {
                            if (prod.equals("")) {
                                prod = temp[0];
                            }
                            if (Qty.equals("")) {
                                qty = Integer.parseInt(temp[1]);
                            } else {
                                qty = Integer.parseInt(Qty) + Integer.parseInt(temp[1]);
                            }

                            if (Price.equals("")) {
                                price = Double.parseDouble(temp[2]);
                            } else {
                                price = Double.parseDouble(Price);
                            }

                            itemline[x] = prod + "\t" + qty + "\t" + price;
                            found = true;
                        }
                        x++;

                    }
                    rdfile.close();
                    //Escritura del nuevo producto
                    if (found) {
                        PrintWriter wrfile = new PrintWriter(new FileWriter("datos/items.txt"));

                        for (int j = 0; itemline[j] != null; j++) {
                            wrfile.println(itemline[j]);
                        }

                        wrfile.close();

                        JOptionPane.showMessageDialog(null, "¡Cambios guardados!");
                    } else {
                        JOptionPane.showMessageDialog(null, "¡Producto no encontrado!");
                    }

                    jTextField6.setText("");
                    jTextField7.setText("");
                    jTextField8.setText("");
                    jTextField9.setText("");

                } else {
                    //Si se vuelven a poner los mismos datos 
                    JOptionPane.showMessageDialog(null, "¡No hay cambios aún!");
                }
            }

        } catch (IOException e) {
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "¡Algún dato ingresado es inválido!");

            jTextField6.setText("");
            jTextField7.setText("");
            jTextField8.setText("");
            jTextField9.setText("");
        }


    }//GEN-LAST:event_jButton8ActionPerformed

    private void jTextField9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField9ActionPerformed
        jButton8ActionPerformed(evt);
    }//GEN-LAST:event_jTextField9ActionPerformed

    private void txtIndiceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIndiceActionPerformed

    }//GEN-LAST:event_txtIndiceActionPerformed

    private void jTextField14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField14ActionPerformed
        jButton6ActionPerformed(evt);
    }//GEN-LAST:event_jTextField14ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        //Limpiar en (Add/Borrar)

        jTextField3.setText("");
        jTextField4.setText("");
        jTextField5.setText("");
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        //Borrar dato

        try {
            if (jTextField14.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "¡Ingrese producto!", "¡ERROR!", JOptionPane.ERROR_MESSAGE);
            } else {
                //Leer archivo
                BufferedReader rdfile = new BufferedReader(new FileReader("datos/items.txt"));

                String[] itemline = new String[100];
                String[] temp;
                String delete = jTextField14.getText();
                boolean found = false;

                int x = 0;
                while ((itemline[x] = rdfile.readLine()) != null) {
                    temp = itemline[x].split("\t");

                    if (delete.equals(temp[0])) {
                        x = x + 0;
                        found = true;
                    } else {
                        x++;
                    }

                }

                rdfile.close();
                //Escribir en archivo
                PrintWriter wrfile = new PrintWriter(new FileWriter("datos/items.txt"));
                for (int j = 0; itemline[j] != null; j++) {
                    wrfile.println(itemline[j]);
                }

                wrfile.close();
                //No se encontraron coincidencias
                if (!found) {
                    JOptionPane.showMessageDialog(null, "¡Elemento no enlistado!", "ERROR!", JOptionPane.ERROR_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "¡Borrado con éxito!", "Confirmado", JOptionPane.INFORMATION_MESSAGE);
                }

                jTextField14.setText("");

            }
        } catch (IOException e) {
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // Agregra producto
//recursivos();
        try {
            if (jTextField3.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "¡Ingrese producto!", "Error!", JOptionPane.ERROR_MESSAGE);
            } else {
                BufferedReader rdfile = new BufferedReader(new FileReader("datos/items.txt"));

                String[] itemline = new String[100];
                String prod = "";
                int qty = 0;
                double price = 0.0;
                boolean found = false;

                int x = 0;
                while ((itemline[x] = rdfile.readLine()) != null) {
                    x++;
                }
                rdfile.close();

                if (!(x >= 100)) {
                    prod = jTextField3.getText();
                    // comprueba si el elemento ya está en la lista
                    for (int j = 0; itemline[j] != null; j++) {     
                        String[] temp = itemline[j].split("\t");

                        if (prod.equals(temp[0])) {
                            found = true;
                        }
                    }

                    if (found) {
                        JOptionPane.showMessageDialog(null, "¡Producto ya existente!\nSugerencia: Actualiza el dato", "", JOptionPane.WARNING_MESSAGE);
                    } else {
                        //Ingresar a variables lo escrito en los txt´s
                        qty = Integer.parseInt(jTextField4.getText());
                        price = Double.parseDouble(jTextField5.getText());

                        itemline[x] = prod + "\t" + qty + "\t" + price;
                        //Registra los nuevos datos
                        PrintWriter wrfile = new PrintWriter(new FileWriter("datos/items.txt"));

                        for (int j = 0; itemline[j] != null; j++) {
                            wrfile.println(itemline[j]);
                        }

                        wrfile.close();

                        JOptionPane.showMessageDialog(null, "¡Agregado!", "Confirmado", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    //Si excede el espacio de 100 Productos
                    JOptionPane.showMessageDialog(null, "¡Inventario lleno!", "Precaución", JOptionPane.WARNING_MESSAGE);
                }
            }

            jTextField3.setText("");
            jTextField4.setText("");
            jTextField5.setText("");

        } catch (IOException e) {
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "¡Algún dato ingresado es inválido!", "¡Precaución!", JOptionPane.WARNING_MESSAGE);

            jTextField3.setText("");
            jTextField4.setText("");
            jTextField5.setText("");
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed

    }//GEN-LAST:event_jTextField5ActionPerformed

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed

    }//GEN-LAST:event_jTextField4ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed

    }//GEN-LAST:event_jTextField3ActionPerformed

    private void bDeAaZActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bDeAaZActionPerformed
//String salida = "";
        condicion = 1;
        //Lectura de archivo donde se encuentran los productos
        try {
            FileReader fr = new FileReader("datos/items.txt");
            BufferedReader br = new BufferedReader(fr);
            String aux = "";
            String linea = "";
            while ((linea = br.readLine()) != null) {
                aux = linea;
                String[] alumnos = aux.split("\n");
                for (int i = 0; i < alumnos.length; i++) {
                    String[] datos = alumnos[i].split("\t");
                    String nombre = datos[0];
                    int carrera = Integer.parseInt(datos[1]);
                    float promedio = Float.parseFloat(datos[2]);
                    Ropa a = new Ropa(nombre, carrera, promedio);
                    nodoA nodo = new nodoA(a);
                    arbol.Insertar(nodo);
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        //Inicializar Fila
        for (int r = 0; r < 100; r++) { 
            //Inicializar columna
            for (int c = 0; c < 4; c++) { 
                jTable1.setValueAt(null, r, c);
            }
        }

     //Se crea un arreglo con el tamaño del arbol
        Ropa[] ropa = new Ropa[arbol.primero.size()];
        arbol.imprimirPre();
        ArrayList<Ropa> aux = new ArrayList<>();
       

        for (int i = 0; i < arbol.primero.size(); i++) {
            aux.add(arbol.primero.get(i));
        }
        ropa = aux.toArray(new Ropa[aux.size()]);
        for (int i = 0; i < aux.size(); i++) {
        }

        orden.Arreglo(ropa);
//        System.out.println("\nLeyendo el primer arreglo\n");
        orden.quick(ropa, 0, ropa.length - 1);
//        System.out.println("\nTerminado\n");

        try {
            FileWriter fw = new FileWriter("datos/nuevo.txt");
            PrintWriter pw = new PrintWriter(fw);
            for (int i = 0; i < orden.ropita().length; i++) {
                pw.println(orden.ropita[i].getNombrePro() + "\t" + orden.ropita[i].getCantidad() + "\t" + orden.ropita[i].getPrecio());
            }
            pw.close();
            fw.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        try {
                 //Inicializar Fila
            for (int r = 0; r < 100; r++) { 
                     //Inicializar columna
                for (int c = 0; c < 4; c++) { 
                    jTable1.setValueAt(null, r, c);
                }
            }

            BufferedReader rdfile = new BufferedReader(new FileReader("datos/nuevo.txt"));

            String[] item = new String[100];
            String[] temp;

            int x = 0;  //Leer archivo
            while ((item[x] = rdfile.readLine()) != null) {
                temp = item[x].split("\t");
                jTable1.setValueAt((1000 + x + 1), x, 0);
                for (int j = 1; j < 4; j++) {
                    jTable1.setValueAt(temp[j - 1], x, j);
                }

                x++;
            }
            rdfile.close();

        } catch (IOException e) {
        }

//            for (int i = 0; i < orden.ropita().length; i++) {
//                jTable1.setValueAt(1000+i+1, i, 0);
//                for (int j = 1; j < 4; j++) {
//                    if(j==1){
//                    jTable1.setValueAt(orden.ropita[i].getNombrePro(),i, j);
//                    }
//                    else if(j==2){
//                        jTable1.setValueAt(orden.ropita[i].getCantidad(), i, j);
//                    }
//                    else if(j==3){
//                        jTable1.setValueAt(orden.ropita[i].getPrecio(), i, j);
//                    }
//                }
//        }
//            aux=null;
//            ropa=null;
bDeAaZ.setEnabled(false);
    }//GEN-LAST:event_bDeAaZActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       Menu ver = new Menu();
       ver.setVisible(true);
       ver.setDefaultCloseOperation(Menu.DISPOSE_ON_CLOSE); 
       this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed
//public void recursivos(){
//    int y=0;
//    int[]cantidad=null;
//    float[]precios = null;
//try {
//            FileReader fr = new FileReader("datos/items.txt");
//            BufferedReader br = new BufferedReader(fr);
//            String aux = "";
//            String linea = "";
//            
//                        while((linea = br.readLine()) != null){
//               y++;
//            }
//cantidad=new int[y];
//        precios=new float[y];
//            while((linea = br.readLine()) != null){
//                aux = linea;
//                String [] alumnos = aux.split("\n");
//                for (int i = 0; i < alumnos.length; i++) {
//                    String [] datos = alumnos[i].split("\t");
//                    String nombre = datos[0];
//                    cantidad[i] = Integer.parseInt(datos[1]);
//                    precios[i] = Float.parseFloat(datos[2]);
//                    //Ropa a = new Ropa(nombre, carrera, promedio);
//                   // nodoA nodo=new nodoA(a);
//                   // arbol.Insertar(nodo);
//                   //JOptionPane.showMessageDialog(null, inversion(i, i, precios));
//                   //JOptionPane.showMessageDialog(null, productos(i, i, cantidad));
//                }
//            }
//            //salida = "La lectura del archivo se realizó correctamente";
//        } catch (Exception e) {
//            JOptionPane.showMessageDialog(null, e.getMessage());
//        }
//JOptionPane.showMessageDialog(null, inversion(0, precios.length-1, precios));
//                   JOptionPane.showMessageDialog(null, productos(0, cantidad.length-1, cantidad));
//}

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login.Desicion().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bDeAaZ;
    private javax.swing.JButton bPagar;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    public javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JList<String> lista1;
    private javax.swing.JTextField txtCantidad;
    private javax.swing.JTextField txtIndice;
    // End of variables declaration//GEN-END:variables
}
