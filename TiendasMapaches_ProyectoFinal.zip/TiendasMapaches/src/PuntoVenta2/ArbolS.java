package PuntoVenta2;

import java.util.ArrayList;

public class ArbolS {

    nodoA raiz;
    ArrayList<Ropa> primero =new ArrayList<Ropa>();
    ArrayList<String> segundo =new ArrayList<String>();
    ArrayList<String> tercero =new ArrayList<String>();
    
    public ArbolS() {
        raiz = null;
    }

    public void Insertar(nodoA n) {
        if (raiz == null) {
            raiz = n;
        } else {
            nodoA a = null;
            nodoA raizA = raiz;
            while(raizA != null){
                a = raizA;
                if(n.dato.getNombrePro().compareTo(raizA.dato.getNombrePro()) <= 0){
                    raizA = raizA.izq;
                }
                else{
                    raizA = raizA.der;
                }
            }
            if(n.dato.getNombrePro().compareTo(a.dato.getNombrePro()) <= 0){
                a.izq = n;
            }
            else{
                a.der  = n;
            }
        }
    }

    private void imprimirPre(nodoA n) {
        if (n != null) {
            System.out.print(n.dato.getNombrePro() + "-");
            primero.add(n.dato);
            imprimirPre(n.izq);
            imprimirPre(n.der);
        }
    }
    
    public void imprimirPre() {
        imprimirPre(raiz);
    }

    private void imprimirIn(nodoA n) {
        if (n != null) {
            imprimirIn(n.izq);
                        segundo.add(n.dato.getNombrePro());

            System.out.print(n.dato.getNombrePro() + "-");
            imprimirIn(n.der);
        }
    }

    public void imprimirIn() {
        imprimirIn(raiz);
    }

    private void imprimirPost(nodoA n) {
        if (n != null) {
            imprimirPost(n.izq);
            imprimirPost(n.der);
            tercero.add(n.dato.getNombrePro());
            System.out.print(n.dato.getNombrePro() + "-");
            
        }
    }

    public void imprimirPost() {
        imprimirPost(raiz);
    }
    public ArrayList primero(){
        return primero;
    }
    public ArrayList segundo(){
        return segundo;
    }
    public ArrayList tercero(){
        return tercero;
    }
}
