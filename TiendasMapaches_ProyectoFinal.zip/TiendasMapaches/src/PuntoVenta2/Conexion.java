package PuntoVenta2;


public class Conexion {
    
}
