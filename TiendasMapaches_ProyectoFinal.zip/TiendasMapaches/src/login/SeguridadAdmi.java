
package login;

import javax.swing.JOptionPane;

public class SeguridadAdmi {

   
    String res;

    public boolean validarUsuario(String usuarios[], String user, String pwd, int intentos) {
        boolean encontrado = false;
        for (int i = 0; i < usuarios.length; i++) {
            if (usuarios[i].equalsIgnoreCase(user) && usuarios[i + 1].equalsIgnoreCase(pwd)) {
                res = "Bienvenido " + user;
                encontrado = true;
                JOptionPane.showMessageDialog(null, res, " Inicio de sesión", JOptionPane.INFORMATION_MESSAGE);
                intentos = 0;
                Ventaslogin.setIntentos(intentos);
                Usuarios.Visual ver = new  Usuarios.Visual();
                ver.setVisible(true);
                
               return true;
            }
        }
        if (encontrado == false) {
            res = " Clave y/o usuarios incorrectos van " + intentos + " fallidos";
            JOptionPane.showMessageDialog(null, res, " Incios de sesión ", JOptionPane.ERROR_MESSAGE);
        }
        if (intentos > 2) {
            JOptionPane.showMessageDialog(null, " 3 intentos fallidos esto se cerrara ", " Inicio de sesión", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }
        return false;
    }
}
